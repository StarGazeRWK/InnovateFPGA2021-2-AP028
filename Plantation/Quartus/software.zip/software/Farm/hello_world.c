/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <stdio.h>
#include <unistd.h>
#include "alt_types.h"
#include "altera_avalon_spi_regs.h"
#include "altera_avalon_spi.h"
#include "altera_avalon_i2c_regs.h"
#include "altera_avalon_i2c.h"
#include "system.h"
#include "altera_avalon_pio_regs.h"
#include <io.h>
#include <stdlib.h>


#define HUMIDI_SENSOR_VALUE    (0x10C)
#define TEMPER_SENSOR_VALUE    (0x110)
#define PH_SENSOR_VALUE    (0x114)

#define MAX_TIMINGS	85
#define DEBUG 0
#define WAIT_TIME 2000

//DHT22
char mode = 'c';      // valid modes are c, f, h
int data[5] = { 0, 0, 0, 0, 0 };
float temp_cels = -1;
float temp_fahr = -1;
float humidity  = -1;

//pH
alt_u8 pHvalue;

//lcd
#define SLAVE_ADDRESS_LCD 0x4E // change this according to ur setup
ALT_AVALON_I2C_DEV_t *i2c_dev; //pointer to instance structure
ALT_AVALON_I2C_STATUS_CODE status;

alt_u8 send_S;
alt_u8 rcvd_M;
alt_u8 count;

void sendSharedMemory()
{
	unsigned offst;
	unsigned *p;

	offst = TEMPER_SENSOR_VALUE>>2;
	p =(unsigned *)&temp_cels;    IOWR(NIOS_SYSTEM_SHARED_MEMORY_BASE, offst++, *p);
	offst = HUMIDI_SENSOR_VALUE>>2;
	p =(unsigned *)&humidity;    IOWR(NIOS_SYSTEM_SHARED_MEMORY_BASE, offst++, *p);
	offst = PH_SENSOR_VALUE>>2;
	p =(unsigned *)&pHvalue;    IOWR(NIOS_SYSTEM_SHARED_MEMORY_BASE, offst++, *p);
}

int dht_routine()
{
	alt_u8 laststate = 0x01;
	alt_u8 counter	= 0;
	alt_u8 j = 0;
	alt_u8 i;

	data[0] = data[1] = data[2] = data[3] = data[4] = 0;

	/* pull pin down for 18 milliseconds */
	IOWR_ALTERA_AVALON_PIO_DATA(NIOS_SYSTEM_DHT22_PIO_BASE, 0x00);
	usleep(18000000);

	IOWR_ALTERA_AVALON_PIO_DATA(NIOS_SYSTEM_DHT22_PIO_BASE, 0x01);

	/* detect change and read data */
	for ( i = 0; i < MAX_TIMINGS; i++ ) {
		counter = 0;
		while ( IORD_ALTERA_AVALON_PIO_DATA(NIOS_SYSTEM_DHT22_PIO_BASE) == laststate ) {
			counter++;
			usleep(1000);
			if ( counter == 255 ) {
				break;
			}
		}
		laststate = IORD_ALTERA_AVALON_PIO_DATA(NIOS_SYSTEM_DHT22_PIO_BASE);

		if ( counter == 255 )
			break;

		/* ignore first 3 transitions */
		if ( (i >= 4) && (i % 2 == 0) ) {
			/* shove each bit into the storage bytes */
			data[j / 8] <<= 1;
			if ( counter > 16 )
				data[j / 8] |= 1;
			j++;
		}
	}

	/*
	 * check we read 40 bits (8bit x 5 ) + verify checksum in the last byte
	 * print it out if data is good
	 */
	if ( (j >= 40) && (data[4] == ( (data[0] + data[1] + data[2] + data[3]) & 0xFF) ) ) {
		float h = (float)((data[0] << 8) + data[1]) / 10;
		if ( h > 100 ) {
			h = data[0];	// for DHT11
		}
		float c = (float)(((data[2] & 0x7F) << 8) + data[3]) / 10;
		if ( c > 125 ) {
			c = data[2];	// for DHT11
		}
		if ( data[2] & 0x80 ) {
			c = -c;
		}
		temp_cels = c;
		temp_fahr = c * 1.8f + 32;
		humidity = h;
		if (DEBUG) printf( "read_dht_data() Humidity = %.1f %% Temperature = %.1f *C (%.1f *F)\n", humidity, temp_cels, temp_fahr );
		return 0; // OK
		} else {
			if (DEBUG) printf( "read_dht_data() Data not good, skip\n" );
			temp_cels = temp_fahr = humidity = -1;
			return 1; // NOK
		}
}

int lcd_send_cmd (char cmd)
{
	char data_u, data_l;
	alt_u8 data_t[4];
	data_u = (cmd&0xf0);
	data_l = ((cmd<<4)&0xf0);
	data_t[0] = data_u|0x0C;  //en=1, rs=0
	data_t[1] = data_u|0x08;  //en=0, rs=0
	data_t[2] = data_l|0x0C;  //en=1, rs=0
	data_t[3] = data_l|0x08;  //en=0, rs=0

	for (int i=0;i<4;i++)
	{
		status=alt_avalon_i2c_master_tx(i2c_dev, data_t, 4, ALT_AVALON_I2C_NO_INTERRUPTS);
		if (status!=ALT_AVALON_I2C_SUCCESS) return 1; //FAIL
	}
}

int lcd_send_data (char data)
{
	char data_u, data_l;
	alt_u8 data_t[4];
	data_u = (data&0xf0);
	data_l = ((data<<4)&0xf0);
	data_t[0] = data_u|0x0D;  //en=1, rs=1
	data_t[1] = data_u|0x09;  //en=0, rs=1
	data_t[2] = data_l|0x0D;  //en=1, rs=1
	data_t[3] = data_l|0x09;  //en=0, rs=1

	for (int i=0;i<4;i++)
	{
		status=alt_avalon_i2c_master_tx(i2c_dev, data_t, 4, ALT_AVALON_I2C_NO_INTERRUPTS);
		if (status!=ALT_AVALON_I2C_SUCCESS) return 1; //FAIL
	}
}

int i2c_config()
{
	alt_u8 txbuffer[0x200];
	alt_u8 rxbuffer[0x200];
	int i;

	//get a pointer to the avalon i2c instance
	i2c_dev = alt_avalon_i2c_open("/dev/i2c_2");
	if (NULL==i2c_dev)
	{
	printf("Error: Cannot find /dev/i2c_2\n");
	return 1;
	}
	//set the address of the device using
	alt_avalon_i2c_master_target_set(i2c_dev,SLAVE_ADDRESS_LCD);
}
void lcd_init (void)
{
	// 4 bit initialisation
	usleep(40000);  // wait for >40ms
	lcd_send_cmd (0x30);
	usleep(5000);  // wait for >4.1ms
	lcd_send_cmd (0x30);
	usleep(100);  // wait for >100us
	lcd_send_cmd (0x30);
	usleep(10000000);
	lcd_send_cmd (0x20);  // 4bit mode
	usleep(10000000);

  // dislay initialisation
	lcd_send_cmd (0x28); // Function set --> DL=0 (4 bit mode), N = 1 (2 line display) F = 0 (5x8 characters)
	usleep(1000000);
	lcd_send_cmd (0x08); //Display on/off control --> D=0,C=0, B=0  ---> display off
	usleep(1000000);
	lcd_send_cmd (0x01);  // clear display
	usleep(1000000);
	usleep(1000000);
	lcd_send_cmd (0x06); //Entry mode set --> I/D = 1 (increment cursor) & S = 0 (no shift)
	usleep(1000000);
	lcd_send_cmd (0x0C); //Display on/off control --> D = 1, C and B = 0. (Cursor and blink, last two bits)
}

void lcd_display()
{
	char str[15];
	int i=0;

	sprintf(str, "%f", temp_cels);
	while (i<15) lcd_send_data (str[i]);

	sprintf(str, "%f", humidity);
	while (i<15) lcd_send_data (str[i]);

	sprintf(str, "%f", pHvalue);
	while (i<15) lcd_send_data (str[i]);
}

void pH_initialize()
{
	cn0398.setup();
	cn0398.init();

	timer.sleep(500);
	printf("Initialization complete!\r\n");

	cn0398.calibrate_ph();
	/*
	send_S = 255 -count;
	IOWR_ALTERA_AVALON_SPI_TXDATA(NIOS_SYSTEM_PH_SENSOR_ANALOGDEVICE_BASE,send_S);

	usleep(75);
	rcvd_M = IORD_ALTERA_AVALON_SPI_RXDATA(NIOS_SYSTEM_PH_SENSOR_ANALOGDEVICE_BASE);


	printf("pH sent = %i, master receive = i", send_S, rcvd_M);

	count++;
	usleep(1000000);
	*/
}

void ph_routine()
{
	cn0398.use_nernst = true;
	cn0398.set_data();
	cn0398.display_data();
	usleep(5000000);
}

int main()
{
  printf("Hello from Nios II!\n");

  count =0;
  lcd_init();
  i2c_config();
  pH_initialize();

  while(1)
  {
	  pH_routine();
	  dht_routine();
	  sendSharedMemory();
	  lcd_display();
  }
  return 0;
}
