#ifndef LCDI2C_H_
#define LCDI2C_H_


bool LCD_REG_WRITE(int file, uint8_t address, uint8_t value);

bool LCD_Init(int file);


#endif /*LCDI2C_H_*/